// Lightweight data - 15 courses, 15 events, 6 clubs

export type Course = {
  id: string;
  code: string;
  title: string;
  school: string;
  tags: string[];
  prereqs: string[];
  workload: number;
  credits: number;
};

export type Event = {
  id: string;
  title: string;
  school: string;
  tags: string[];
  date: string;
  time: string;
};

export type Club = {
  id: string;
  name: string;
  tags: string[];
  emoji: string;
};

export const courses: Course[] = [
  { id: 'c1', code: 'COMS 4771', title: 'Machine Learning', school: 'SEAS', tags: ['AI', 'ML'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c2', code: 'COMS 4995', title: 'Deep Learning', school: 'SEAS', tags: ['AI', 'Deep Learning'], prereqs: ['c1'], workload: 5, credits: 3 },
  { id: 'c3', code: 'COMS 4701', title: 'Artificial Intelligence', school: 'SEAS', tags: ['AI'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c4', code: 'STAT 4243', title: 'Applied Data Science', school: 'SEAS', tags: ['Data Science'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c5', code: 'IEOR 4575', title: 'ML for Operations Research', school: 'SEAS', tags: ['ML', 'Operations'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c6', code: 'IEOR 4700', title: 'Financial Engineering', school: 'SEAS', tags: ['Finance', 'Quant'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c7', code: 'CSOR 4231', title: 'Analysis of Algorithms', school: 'SEAS', tags: ['Algorithms', 'Quant'], prereqs: [], workload: 5, credits: 3 },
  { id: 'c8', code: 'B8306', title: 'Corporate Finance', school: 'CBS', tags: ['Finance', 'Business'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c9', code: 'B8144', title: 'Python for Analytics', school: 'CBS', tags: ['Data Science', 'Python'], prereqs: [], workload: 2, credits: 1.5 },
  { id: 'c10', code: 'ECON 3412', title: 'Climate Economics', school: 'GSAS', tags: ['Climate', 'Economics'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c11', code: 'SIPA U6250', title: 'Energy & Environment', school: 'SIPA', tags: ['Climate', 'Policy'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c13', code: 'B8405', title: 'Management Consulting', school: 'CBS', tags: ['Consulting', 'Business'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c15', code: 'B8528', title: 'Entrepreneurship & VC', school: 'CBS', tags: ['Entrepreneurship', 'VC'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c16', code: 'ENGI 4800', title: 'Startup Engineering', school: 'SEAS', tags: ['Entrepreneurship', 'Product'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c17', code: 'COMS 4111', title: 'Database Systems', school: 'SEAS', tags: ['Databases', 'Systems'], prereqs: [], workload: 4, credits: 3 },
  { id: 'c18', code: 'COMS 4156', title: 'Software Engineering', school: 'SEAS', tags: ['Software Engineering'], prereqs: [], workload: 5, credits: 3 },
  { id: 'c20', code: 'COMS 4153', title: 'Blockchain', school: 'SEAS', tags: ['Blockchain', 'Fintech'], prereqs: [], workload: 3, credits: 3 },
  { id: 'c26', code: 'COMS 4705', title: 'Natural Language Processing', school: 'SEAS', tags: ['NLP', 'AI'], prereqs: ['c1'], workload: 4, credits: 3 },
  { id: 'c28', code: 'COMS 4121', title: 'Big Data Analytics', school: 'SEAS', tags: ['Data Engineering'], prereqs: ['c17'], workload: 4, credits: 3 },
  { id: 'c30', code: 'STAT 5241', title: 'Statistical ML', school: 'SEAS', tags: ['ML', 'Statistics'], prereqs: [], workload: 4, credits: 3 },
];

export const events: Event[] = [
  { id: 'e1', title: 'Google AI Tech Talk', school: 'SEAS', tags: ['AI', 'Tech', 'Career'], date: '2026-02-05', time: '6:00 PM' },
  { id: 'e2', title: 'Goldman Sachs Quant Info Session', school: 'SEAS', tags: ['Finance', 'Quant', 'Career'], date: '2026-02-10', time: '5:00 PM' },
  { id: 'e3', title: 'McKinsey Case Workshop', school: 'CBS', tags: ['Consulting', 'Career'], date: '2026-02-12', time: '6:00 PM' },
  { id: 'e4', title: 'Startup Founders Panel', school: 'All', tags: ['Entrepreneurship', 'Startups'], date: '2026-02-15', time: '7:00 PM' },
  { id: 'e5', title: 'Amazon ML Engineers Happy Hour', school: 'SEAS', tags: ['ML', 'Networking'], date: '2026-02-18', time: '6:00 PM' },
  { id: 'e6', title: 'Climate Tech Startup Showcase', school: 'Climate', tags: ['Climate', 'Entrepreneurship'], date: '2026-02-08', time: '5:00 PM' },
  { id: 'e7', title: 'Renewable Energy Policy Debate', school: 'SIPA', tags: ['Climate', 'Policy'], date: '2026-02-20', time: '4:00 PM' },
  { id: 'e10', title: 'LLM Applications Workshop', school: 'All', tags: ['AI', 'NLP', 'Workshop'], date: '2026-02-14', time: '10:00 AM' },
  { id: 'e12', title: 'International Students Mixer', school: 'All', tags: ['Networking', 'Social'], date: '2026-02-01', time: '5:00 PM' },
  { id: 'e15', title: 'Crypto Trading Competition', school: 'All', tags: ['Blockchain', 'Finance'], date: '2026-02-09', time: '2:00 PM' },
  { id: 'e16', title: 'Quantitative Finance Seminar', school: 'SEAS', tags: ['Quant', 'Finance'], date: '2026-02-13', time: '4:30 PM' },
  { id: 'e17', title: 'FinTech Innovation Summit', school: 'CBS', tags: ['Finance', 'Tech'], date: '2026-02-21', time: '9:00 AM' },
  { id: 'e27', title: 'Excel Modeling Bootcamp', school: 'CBS', tags: ['Finance', 'Workshop'], date: '2026-02-26', time: '6:00 PM' },
  { id: 'e32', title: 'International Career Pathways', school: 'All', tags: ['Career', 'International'], date: '2026-03-04', time: '5:00 PM' },
  { id: 'e33', title: 'Product Management 101', school: 'All', tags: ['Product', 'Career'], date: '2026-02-29', time: '6:30 PM' },
];

export const clubs: Club[] = [
  { id: 'cl1', name: 'ADI (App Development)', tags: ['Tech', 'Programming'], emoji: '💻' },
  { id: 'cl2', name: 'Data Science Society', tags: ['Data Science', 'ML'], emoji: '📊' },
  { id: 'cl4', name: 'Blockchain Club', tags: ['Blockchain', 'Crypto'], emoji: '⛓️' },
  { id: 'cl5', name: 'Venture Community', tags: ['Entrepreneurship', 'VC'], emoji: '🚀' },
  { id: 'cl6', name: 'Consulting Club', tags: ['Consulting', 'Business'], emoji: '💼' },
  { id: 'cl8', name: 'Climate Solutions Lab', tags: ['Climate', 'Sustainability'], emoji: '🌍' },
];
