// Synthetic example personas with complete user journeys

export type Persona = {
  id: string;
  name: string;
  avatar: string;
  school: string;
  program: string;
  interests: string[];
  careerGoals: string[];
  story: string;
  coursePlan: {
    term: string;
    courses: string[];
  }[];
  savedEvents: string[];
  achievements: string[];
  level: number;
  xp: number;
};

export const EXAMPLE_PERSONAS: Persona[] = [
  {
    id: 'alex',
    name: 'Alex Chen',
    avatar: '👨‍💻',
    school: 'SEAS',
    program: 'MS Computer Science',
    interests: ['Machine Learning', 'AI', 'Entrepreneurship'],
    careerGoals: ['DS/AI', 'Product Management'],
    story: 'International student from Taiwan. Wants to break into AI product management at a top tech company.',
    coursePlan: [
      {
        term: 'Fall 2025',
        courses: ['c1', 'c4', 'c17', 'c18'],
      },
      {
        term: 'Spring 2026',
        courses: ['c2', 'c26', 'c5'],
      },
    ],
    savedEvents: ['e1', 'e5', 'e10', 'e12', 'e33'],
    achievements: ['first_steps', 'course_explorer', 'planner_pro', 'event_hunter'],
    level: 4,
    xp: 650,
  },
  {
    id: 'maria',
    name: 'Maria Garcia',
    avatar: '👩‍🎓',
    school: 'CBS',
    program: 'MBA',
    interests: ['Finance', 'Consulting', 'Climate Tech'],
    careerGoals: ['Consulting', 'Climate Tech'],
    story: 'Former engineer pivoting to climate consulting. Looking to combine technical background with business strategy.',
    coursePlan: [
      {
        term: 'Fall 2025',
        courses: ['c8', 'c13', 'c10', 'c15'],
      },
      {
        term: 'Spring 2026',
        courses: ['c11', 'c6', 'c9'],
      },
    ],
    savedEvents: ['e3', 'e6', 'e7', 'e17', 'e32'],
    achievements: ['first_steps', 'course_explorer', 'planner_pro', 'networker'],
    level: 3,
    xp: 450,
  },
  {
    id: 'raj',
    name: 'Raj Patel',
    avatar: '👨‍🔬',
    school: 'SEAS',
    program: 'MS Financial Engineering',
    interests: ['Quant', 'Finance', 'Algorithms'],
    careerGoals: ['Quant', 'Finance'],
    story: 'Math major aiming for quantitative trading. Focused on building strong technical and financial skills.',
    coursePlan: [
      {
        term: 'Fall 2025',
        courses: ['c6', 'c7', 'c30', 'c20'],
      },
      {
        term: 'Spring 2026',
        courses: ['c5', 'c28', 'c4'],
      },
    ],
    savedEvents: ['e2', 'e15', 'e16', 'e27'],
    achievements: ['first_steps', 'course_explorer', 'planner_pro', 'decision_maker'],
    level: 5,
    xp: 1100,
  },
];

// Course recommendations for each persona
export const PERSONA_RECOMMENDATIONS = {
  alex: {
    courses: [
      { id: 'c1', score: 95, reason: 'Perfect match for ML interest' },
      { id: 'c3', score: 90, reason: 'AI foundation course' },
      { id: 'c26', score: 88, reason: 'Trending in AI product roles' },
      { id: 'c16', score: 75, reason: 'Entrepreneurship + Tech combo' },
    ],
    events: [
      { id: 'e1', score: 98, reason: 'Google tech talk on AI' },
      { id: 'e10', score: 95, reason: 'LLM workshop for PM skills' },
      { id: 'e33', score: 85, reason: 'Product management fundamentals' },
    ],
  },
  maria: {
    courses: [
      { id: 'c10', score: 95, reason: 'Climate + Business strategy' },
      { id: 'c13', score: 92, reason: 'Core consulting skills' },
      { id: 'c11', score: 88, reason: 'Energy policy expertise' },
      { id: 'c8', score: 75, reason: 'Finance fundamentals for consulting' },
    ],
    events: [
      { id: 'e6', score: 98, reason: 'Climate tech startups' },
      { id: 'e3', score: 95, reason: 'McKinsey case workshop' },
      { id: 'e7', score: 90, reason: 'Energy policy debate' },
    ],
  },
  raj: {
    courses: [
      { id: 'c6', score: 98, reason: 'Core for quant finance' },
      { id: 'c7', score: 95, reason: 'Essential algorithms knowledge' },
      { id: 'c30', score: 90, reason: 'Statistical methods for trading' },
      { id: 'c5', score: 85, reason: 'ML applications in finance' },
    ],
    events: [
      { id: 'e2', score: 98, reason: 'Goldman quant recruiting' },
      { id: 'e16', score: 95, reason: 'Quant finance seminar' },
      { id: 'e15', score: 88, reason: 'Crypto trading skills' },
    ],
  },
};

// Decision validation examples
export const DECISION_EXAMPLES = [
  {
    persona: 'alex',
    course: 'c2',
    decision: 'Should I take Deep Learning now or wait?',
    considerations: [
      { type: 'prerequisite', text: 'Requires COMS 4771 (Machine Learning)', status: 'completed' },
      { type: 'workload', text: 'High workload (5/5)', status: 'warning' },
      { type: 'career', text: 'Highly relevant for AI roles', status: 'positive' },
      { type: 'timing', text: 'Only offered in Spring', status: 'info' },
    ],
    recommendation: 'Take it! You have the prereq and it\'s crucial for AI PM roles. Pair with lighter courses.',
    confidence: 85,
  },
  {
    persona: 'maria',
    course: 'c11',
    decision: 'Is this climate course worth it for consulting?',
    considerations: [
      { type: 'cross_school', text: 'SIPA course requires approval', status: 'warning' },
      { type: 'career', text: 'Growing demand for climate consultants', status: 'positive' },
      { type: 'network', text: 'Connect with climate policy experts', status: 'positive' },
      { type: 'workload', text: 'Moderate workload (3/5)', status: 'info' },
    ],
    recommendation: 'Yes! Climate consulting is hot. Just get cross-school approval from CBS.',
    confidence: 90,
  },
  {
    persona: 'raj',
    course: 'c20',
    decision: 'Will Blockchain help for quant roles?',
    considerations: [
      { type: 'career', text: 'Some hedge funds trading crypto', status: 'positive' },
      { type: 'alternative', text: 'Algorithms course might be more core', status: 'warning' },
      { type: 'timing', text: 'Only in Fall, doesn\'t conflict', status: 'positive' },
      { type: 'workload', text: 'Light workload (3/5)', status: 'positive' },
    ],
    recommendation: 'Good elective, but prioritize core quant courses first (Algorithms, Stats).',
    confidence: 70,
  },
];
