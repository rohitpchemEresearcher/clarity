// Gamification system - achievements, XP, levels, streaks

export type Achievement = {
  id: string;
  name: string;
  description: string;
  icon: string;
  xp: number;
  unlocked: boolean;
  progress?: number;
  total?: number;
};

export type UserProgress = {
  level: number;
  xp: number;
  xpToNextLevel: number;
  achievements: Achievement[];
  streak: number;
  coursesPlanned: number;
  eventsSaved: number;
  decisionsValidated: number;
};

// XP requirements for each level
const XP_PER_LEVEL = [0, 100, 250, 500, 1000, 2000, 3500, 5500, 8000, 12000];

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_steps',
    name: 'First Steps',
    description: 'Complete your profile',
    icon: '🎯',
    xp: 50,
    unlocked: false,
  },
  {
    id: 'course_explorer',
    name: 'Course Explorer',
    description: 'Add your first course to a plan',
    icon: '📚',
    xp: 100,
    unlocked: false,
  },
  {
    id: 'planner_pro',
    name: 'Planner Pro',
    description: 'Plan a full semester (4+ courses)',
    icon: '🎓',
    xp: 200,
    unlocked: false,
    progress: 0,
    total: 4,
  },
  {
    id: 'event_hunter',
    name: 'Event Hunter',
    description: 'Save 5 events',
    icon: '🎪',
    xp: 150,
    unlocked: false,
    progress: 0,
    total: 5,
  },
  {
    id: 'risk_aware',
    name: 'Risk Aware',
    description: 'Review all risk flags for a course',
    icon: '⚠️',
    xp: 100,
    unlocked: false,
  },
  {
    id: 'decision_maker',
    name: 'Decision Maker',
    description: 'Validate 10 course decisions',
    icon: '✅',
    xp: 250,
    unlocked: false,
    progress: 0,
    total: 10,
  },
  {
    id: 'networker',
    name: 'Networker',
    description: 'Explore 3 clubs',
    icon: '🤝',
    xp: 100,
    unlocked: false,
    progress: 0,
    total: 3,
  },
  {
    id: 'streak_starter',
    name: 'Streak Starter',
    description: 'Use the app 3 days in a row',
    icon: '🔥',
    xp: 200,
    unlocked: false,
    progress: 0,
    total: 3,
  },
  {
    id: 'master_planner',
    name: 'Master Planner',
    description: 'Plan 2 full semesters',
    icon: '🏆',
    xp: 500,
    unlocked: false,
    progress: 0,
    total: 2,
  },
];

export function calculateLevel(xp: number): number {
  for (let i = XP_PER_LEVEL.length - 1; i >= 0; i--) {
    if (xp >= XP_PER_LEVEL[i]) {
      return i + 1;
    }
  }
  return 1;
}

export function getXPToNextLevel(xp: number): number {
  const level = calculateLevel(xp);
  if (level >= XP_PER_LEVEL.length) {
    return 0; // Max level
  }
  return XP_PER_LEVEL[level] - xp;
}

export function initializeProgress(): UserProgress {
  return {
    level: 1,
    xp: 0,
    xpToNextLevel: 100,
    achievements: ACHIEVEMENTS.map(a => ({ ...a })),
    streak: 0,
    coursesPlanned: 0,
    eventsSaved: 0,
    decisionsValidated: 0,
  };
}

export function awardXP(progress: UserProgress, xp: number, reason: string): { 
  progress: UserProgress; 
  leveledUp: boolean;
  notification: string;
} {
  const oldLevel = progress.level;
  const newXP = progress.xp + xp;
  const newLevel = calculateLevel(newXP);
  
  const notification = `+${xp} XP: ${reason}`;
  
  return {
    progress: {
      ...progress,
      xp: newXP,
      level: newLevel,
      xpToNextLevel: getXPToNextLevel(newXP),
    },
    leveledUp: newLevel > oldLevel,
    notification,
  };
}

export function checkAchievement(
  progress: UserProgress,
  achievementId: string
): { progress: UserProgress; unlocked: boolean } {
  const achievement = progress.achievements.find(a => a.id === achievementId);
  
  if (!achievement || achievement.unlocked) {
    return { progress, unlocked: false };
  }

  achievement.unlocked = true;
  
  const { progress: newProgress } = awardXP(
    progress,
    achievement.xp,
    `Unlocked: ${achievement.name}`
  );

  return {
    progress: newProgress,
    unlocked: true,
  };
}

export function updateAchievementProgress(
  progress: UserProgress,
  achievementId: string,
  increment: number = 1
): { progress: UserProgress; completed: boolean } {
  const achievement = progress.achievements.find(a => a.id === achievementId);
  
  if (!achievement || achievement.unlocked || !achievement.total) {
    return { progress, completed: false };
  }

  achievement.progress = (achievement.progress || 0) + increment;
  
  if (achievement.progress >= achievement.total) {
    return checkAchievement(progress, achievementId);
  }

  return { progress, completed: false };
}

// Action tracking
export function trackCourseAdded(progress: UserProgress): UserProgress {
  let newProgress = { ...progress, coursesPlanned: progress.coursesPlanned + 1 };
  
  if (progress.coursesPlanned === 0) {
    const result = checkAchievement(newProgress, 'course_explorer');
    newProgress = result.progress;
  }
  
  if (progress.coursesPlanned >= 3) {
    const result = updateAchievementProgress(newProgress, 'planner_pro', 1);
    newProgress = result.progress;
  }
  
  return newProgress;
}

export function trackEventSaved(progress: UserProgress): UserProgress {
  let newProgress = { ...progress, eventsSaved: progress.eventsSaved + 1 };
  
  const result = updateAchievementProgress(newProgress, 'event_hunter', 1);
  return result.progress;
}

export function trackDecisionValidated(progress: UserProgress): UserProgress {
  let newProgress = { ...progress, decisionsValidated: progress.decisionsValidated + 1 };
  
  const result = updateAchievementProgress(newProgress, 'decision_maker', 1);
  return result.progress;
}
