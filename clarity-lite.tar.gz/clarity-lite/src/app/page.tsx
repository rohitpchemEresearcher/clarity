'use client';

import { useRouter } from 'next/navigation';
import { EXAMPLE_PERSONAS } from '@/lib/personas';
import { Trophy, Sparkles, Zap } from 'lucide-react';

export default function HomePage() {
  const router = useRouter();

  const selectPersona = (personaId: string) => {
    localStorage.setItem('selectedPersona', personaId);
    router.push('/play');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <div className="inline-block mb-4">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full text-sm font-bold animate-pulse-slow">
              🎮 GAMIFIED EDITION
            </div>
          </div>
          <h1 className="text-6xl font-black bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-4">
            Clarity Lite
          </h1>
          <p className="text-xl text-gray-600 mb-2">Level up your Columbia experience</p>
          <div className="flex justify-center gap-4 text-sm">
            <span className="flex items-center gap-1 text-purple-600">
              <Trophy className="w-4 h-4" />
              Earn XP
            </span>
            <span className="flex items-center gap-1 text-pink-600">
              <Sparkles className="w-4 h-4" />
              Unlock Achievements
            </span>
            <span className="flex items-center gap-1 text-blue-600">
              <Zap className="w-4 h-4" />
              Complete Quests
            </span>
          </div>
        </div>

        {/* Persona Selection */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">
            Choose Your Character
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {EXAMPLE_PERSONAS.map((persona) => (
              <button
                key={persona.id}
                onClick={() => selectPersona(persona.id)}
                className="glass rounded-2xl p-6 card-hover border-2 border-transparent hover:border-purple-400 text-left group"
              >
                {/* Avatar & Level */}
                <div className="flex items-start justify-between mb-4">
                  <div className="text-6xl group-hover:animate-bounce-slow">
                    {persona.avatar}
                  </div>
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                    Lvl {persona.level}
                  </div>
                </div>

                {/* Name & Program */}
                <h3 className="text-xl font-bold text-gray-800 mb-1">
                  {persona.name}
                </h3>
                <p className="text-sm text-gray-600 mb-3">
                  {persona.program}
                </p>

                {/* Story */}
                <p className="text-xs text-gray-500 mb-4 line-clamp-2">
                  {persona.story}
                </p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-purple-100 rounded-lg p-2">
                    <div className="text-xs text-purple-600 font-semibold">XP</div>
                    <div className="text-lg font-bold text-purple-700">{persona.xp}</div>
                  </div>
                  <div className="bg-pink-100 rounded-lg p-2">
                    <div className="text-xs text-pink-600 font-semibold">Achievements</div>
                    <div className="text-lg font-bold text-pink-700">{persona.achievements.length}</div>
                  </div>
                </div>

                {/* Interests Tags */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {persona.interests.slice(0, 3).map((interest, i) => (
                    <span
                      key={i}
                      className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full"
                    >
                      {interest}
                    </span>
                  ))}
                </div>

                {/* Play Button */}
                <div className="text-center mt-4 pt-4 border-t border-gray-200">
                  <span className="text-sm font-bold text-purple-600 group-hover:text-pink-600">
                    Play as {persona.name.split(' ')[0]} →
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Features */}
        <div className="glass rounded-2xl p-8 max-w-4xl mx-auto">
          <h3 className="text-lg font-bold text-gray-800 mb-4 text-center">
            🎯 What You'll Experience
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl mb-2">📚</div>
              <div className="font-bold text-gray-800 mb-1">Smart Planning</div>
              <div className="text-xs text-gray-600">
                See how each persona planned their courses with AI recommendations
              </div>
            </div>
            <div>
              <div className="text-3xl mb-2">🎪</div>
              <div className="font-bold text-gray-800 mb-1">Event Quests</div>
              <div className="text-xs text-gray-600">
                Complete quests by attending networking events and workshops
              </div>
            </div>
            <div>
              <div className="text-3xl mb-2">🏆</div>
              <div className="font-bold text-gray-800 mb-1">Achievements</div>
              <div className="text-xs text-gray-600">
                Unlock 9 achievements and reach level 10
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-xs text-gray-500">
          <p>💡 This is a gamified demo with synthetic personas</p>
          <p className="mt-1">Explore different student journeys and decision-making strategies</p>
        </div>
      </div>
    </div>
  );
}
