'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { EXAMPLE_PERSONAS, PERSONA_RECOMMENDATIONS, DECISION_EXAMPLES, Persona } from '@/lib/personas';
import { courses, events, clubs } from '@/lib/data';
import { 
  initializeProgress, 
  trackCourseAdded, 
  trackEventSaved, 
  trackDecisionValidated,
  checkAchievement,
  UserProgress 
} from '@/lib/gamification';
import { 
  Trophy, Star, Zap, BookOpen, Calendar, Users, 
  TrendingUp, Award, CheckCircle, AlertTriangle, Home
} from 'lucide-react';

export default function PlayPage() {
  const router = useRouter();
  const [persona, setPersona] = useState<Persona | null>(null);
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [activeTab, setActiveTab] = useState<'courses' | 'events' | 'decisions' | 'achievements'>('courses');
  const [notification, setNotification] = useState<string | null>(null);
  const [showLevelUp, setShowLevelUp] = useState(false);

  useEffect(() => {
    const selectedId = localStorage.getItem('selectedPersona');
    if (!selectedId) {
      router.push('/');
      return;
    }

    const selectedPersona = EXAMPLE_PERSONAS.find(p => p.id === selectedId);
    if (!selectedPersona) {
      router.push('/');
      return;
    }

    setPersona(selectedPersona);
    
    // Initialize progress from persona or localStorage
    const savedProgress = localStorage.getItem(`progress_${selectedId}`);
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress));
    } else {
      const initial = initializeProgress();
      // Pre-unlock achievements based on persona
      let updated = { ...initial, level: selectedPersona.level, xp: selectedPersona.xp };
      selectedPersona.achievements.forEach(achId => {
        const result = checkAchievement(updated, achId);
        updated = result.progress;
      });
      setProgress(updated);
      localStorage.setItem(`progress_${selectedId}`, JSON.stringify(updated));
    }
  }, [router]);

  const saveProgress = (newProgress: UserProgress) => {
    if (!persona) return;
    setProgress(newProgress);
    localStorage.setItem(`progress_${persona.id}`, JSON.stringify(newProgress));
  };

  const showNotification = (message: string, isLevelUp: boolean = false) => {
    setNotification(message);
    if (isLevelUp) setShowLevelUp(true);
    setTimeout(() => {
      setNotification(null);
      setShowLevelUp(false);
    }, 3000);
  };

  const handleAddCourse = (courseId: string) => {
    if (!progress) return;
    const newProgress = trackCourseAdded(progress);
    saveProgress(newProgress);
    showNotification('+50 XP: Course Added!');
  };

  const handleSaveEvent = (eventId: string) => {
    if (!progress) return;
    const newProgress = trackEventSaved(progress);
    saveProgress(newProgress);
    showNotification('+30 XP: Event Saved!');
  };

  const handleValidateDecision = () => {
    if (!progress) return;
    const newProgress = trackDecisionValidated(progress);
    saveProgress(newProgress);
    showNotification('+25 XP: Decision Validated!');
  };

  if (!persona || !progress) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your journey...</p>
        </div>
      </div>
    );
  }

  const recommendations = PERSONA_RECOMMENDATIONS[persona.id as keyof typeof PERSONA_RECOMMENDATIONS];
  const decisions = DECISION_EXAMPLES.filter(d => d.persona === persona.id);
  const xpProgress = (progress.xp / (progress.xp + progress.xpToNextLevel)) * 100;

  return (
    <div className="min-h-screen p-4 pb-20">
      {/* Notifications */}
      {notification && (
        <div className="fixed top-4 right-4 z-50 animate-bounce">
          <div className={`glass rounded-xl px-6 py-3 shadow-2xl border-2 ${
            showLevelUp ? 'border-yellow-400 bg-gradient-to-r from-yellow-50 to-orange-50' : 'border-green-400'
          }`}>
            <div className="flex items-center gap-2">
              {showLevelUp ? (
                <>
                  <Trophy className="w-5 h-5 text-yellow-600" />
                  <span className="font-bold text-yellow-600">LEVEL UP!</span>
                </>
              ) : (
                <>
                  <Star className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-600">{notification}</span>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto">
        {/* Header with Progress */}
        <div className="glass rounded-2xl p-6 mb-6 border-2 border-purple-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{persona.avatar}</div>
              <div>
                <h1 className="text-2xl font-black text-gray-800">{persona.name}</h1>
                <p className="text-sm text-gray-600">{persona.program}</p>
              </div>
            </div>
            <button
              onClick={() => router.push('/')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition"
            >
              <Home className="w-4 h-4" />
              <span className="text-sm font-medium">Change Character</span>
            </button>
          </div>

          {/* XP Bar */}
          <div className="mb-3">
            <div className="flex justify-between text-sm mb-1">
              <span className="font-bold text-purple-600">Level {progress.level}</span>
              <span className="text-gray-600">{progress.xp} / {progress.xp + progress.xpToNextLevel} XP</span>
            </div>
            <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500"
                style={{ width: `${xpProgress}%` }}
              />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-3">
            <div className="bg-gradient-to-br from-purple-100 to-purple-50 rounded-lg p-3">
              <div className="text-2xl font-bold text-purple-700">{progress.level}</div>
              <div className="text-xs text-purple-600 font-semibold">Level</div>
            </div>
            <div className="bg-gradient-to-br from-pink-100 to-pink-50 rounded-lg p-3">
              <div className="text-2xl font-bold text-pink-700">
                {progress.achievements.filter(a => a.unlocked).length}
              </div>
              <div className="text-xs text-pink-600 font-semibold">Achievements</div>
            </div>
            <div className="bg-gradient-to-br from-blue-100 to-blue-50 rounded-lg p-3">
              <div className="text-2xl font-bold text-blue-700">{progress.coursesPlanned}</div>
              <div className="text-xs text-blue-600 font-semibold">Courses</div>
            </div>
            <div className="bg-gradient-to-br from-green-100 to-green-50 rounded-lg p-3">
              <div className="text-2xl font-bold text-green-700">{progress.eventsSaved}</div>
              <div className="text-xs text-green-600 font-semibold">Events</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="glass rounded-2xl p-2 mb-6 flex gap-2">
          {[
            { id: 'courses', label: 'Courses', icon: BookOpen },
            { id: 'events', label: 'Events', icon: Calendar },
            { id: 'decisions', label: 'Decisions', icon: TrendingUp },
            { id: 'achievements', label: 'Achievements', icon: Trophy },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold transition ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="space-y-6">
          {/* Courses Tab */}
          {activeTab === 'courses' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                📚 Recommended Courses for {persona.name.split(' ')[0]}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.courses.map(rec => {
                  const course = courses.find(c => c.id === rec.id);
                  if (!course) return null;
                  
                  return (
                    <div key={course.id} className="glass rounded-xl p-6 card-hover border-2 border-transparent hover:border-purple-300">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-bold text-purple-600 bg-purple-100 px-2 py-1 rounded">
                              {course.school}
                            </span>
                            <span className="text-xs font-bold text-pink-600 bg-pink-100 px-2 py-1 rounded">
                              {rec.score}% Match
                            </span>
                          </div>
                          <h3 className="font-bold text-gray-800">{course.code}</h3>
                          <p className="text-sm text-gray-600">{course.title}</p>
                        </div>
                        <div className="text-2xl">📖</div>
                      </div>

                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-3">
                        <p className="text-xs text-green-700">
                          <strong>Why this works:</strong> {rec.reason}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {course.tags.map(tag => (
                          <span key={tag} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                        <span>{course.credits} credits</span>
                        <span>Workload: {course.workload}/5</span>
                      </div>

                      <button
                        onClick={() => handleAddCourse(course.id)}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg font-semibold hover:shadow-lg transition"
                      >
                        + Add to Plan (+50 XP)
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Events Tab */}
          {activeTab === 'events' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                🎪 Event Quests for {persona.name.split(' ')[0]}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.events.map(rec => {
                  const event = events.find(e => e.id === rec.id);
                  if (!event) return null;
                  
                  return (
                    <div key={event.id} className="glass rounded-xl p-6 card-hover border-2 border-transparent hover:border-pink-300">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-xs font-bold text-pink-600 bg-pink-100 px-2 py-1 rounded">
                              {rec.score}% Match
                            </span>
                          </div>
                          <h3 className="font-bold text-gray-800 mb-1">{event.title}</h3>
                          <p className="text-xs text-gray-600 mb-2">
                            📅 {event.date} at {event.time}
                          </p>
                        </div>
                        <div className="text-2xl">🎯</div>
                      </div>

                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                        <p className="text-xs text-blue-700">
                          <strong>Quest reward:</strong> {rec.reason}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {event.tags.map(tag => (
                          <span key={tag} className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>

                      <button
                        onClick={() => handleSaveEvent(event.id)}
                        className="w-full bg-gradient-to-r from-pink-600 to-purple-600 text-white py-2 px-4 rounded-lg font-semibold hover:shadow-lg transition"
                      >
                        📌 Save Event (+30 XP)
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Decisions Tab */}
          {activeTab === 'decisions' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                🤔 Decision Scenarios
              </h2>
              <div className="space-y-4">
                {decisions.map((decision, idx) => {
                  const course = courses.find(c => c.id === decision.course);
                  
                  return (
                    <div key={idx} className="glass rounded-xl p-6 border-2 border-blue-200">
                      <div className="flex items-start gap-4 mb-4">
                        <div className="text-3xl">🎓</div>
                        <div className="flex-1">
                          <h3 className="font-bold text-gray-800 mb-1">
                            {course?.code} - {course?.title}
                          </h3>
                          <p className="text-gray-700 mb-3">"{decision.decision}"</p>
                        </div>
                        <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                          {decision.confidence}% Confidence
                        </div>
                      </div>

                      <div className="space-y-2 mb-4">
                        {decision.considerations.map((con, i) => (
                          <div 
                            key={i}
                            className={`flex items-start gap-2 p-3 rounded-lg ${
                              con.status === 'positive' ? 'bg-green-50 border border-green-200' :
                              con.status === 'warning' ? 'bg-orange-50 border border-orange-200' :
                              con.status === 'completed' ? 'bg-blue-50 border border-blue-200' :
                              'bg-gray-50 border border-gray-200'
                            }`}
                          >
                            {con.status === 'positive' && <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />}
                            {con.status === 'warning' && <AlertTriangle className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />}
                            {con.status === 'completed' && <CheckCircle className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />}
                            <p className="text-sm text-gray-700">{con.text}</p>
                          </div>
                        ))}
                      </div>

                      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-300 rounded-lg p-4 mb-4">
                        <p className="text-sm font-semibold text-purple-800 mb-1">
                          💡 Recommendation:
                        </p>
                        <p className="text-sm text-gray-700">
                          {decision.recommendation}
                        </p>
                      </div>

                      <button
                        onClick={handleValidateDecision}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2 px-4 rounded-lg font-semibold hover:shadow-lg transition"
                      >
                        ✅ Validate Decision (+25 XP)
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Achievements Tab */}
          {activeTab === 'achievements' && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                🏆 Achievements
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {progress.achievements.map(achievement => (
                  <div 
                    key={achievement.id}
                    className={`glass rounded-xl p-6 border-2 ${
                      achievement.unlocked
                        ? 'border-yellow-300 bg-gradient-to-br from-yellow-50 to-orange-50'
                        : 'border-gray-200 opacity-50'
                    }`}
                  >
                    <div className="text-center mb-3">
                      <div className={`text-5xl mb-2 ${achievement.unlocked ? 'animate-bounce-slow' : 'grayscale'}`}>
                        {achievement.icon}
                      </div>
                      <h3 className="font-bold text-gray-800 mb-1">
                        {achievement.name}
                      </h3>
                      <p className="text-xs text-gray-600 mb-2">
                        {achievement.description}
                      </p>
                    </div>

                    {achievement.progress !== undefined && achievement.total && !achievement.unlocked && (
                      <div className="mb-2">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600">Progress</span>
                          <span className="font-semibold">{achievement.progress}/{achievement.total}</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                            style={{ width: `${(achievement.progress / achievement.total) * 100}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="text-center">
                      {achievement.unlocked ? (
                        <div className="bg-yellow-100 text-yellow-700 py-2 px-3 rounded-lg font-bold text-sm">
                          ✓ Unlocked! +{achievement.xp} XP
                        </div>
                      ) : (
                        <div className="bg-gray-100 text-gray-600 py-2 px-3 rounded-lg font-semibold text-sm">
                          {achievement.xp} XP
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
